@Suppress("INVISIBLE_MEMBER", "INVISIBLE_REFERENCE")
private fun runShizukuCmd(cmd: String): String {
    val process = Shizuku.newProcess(arrayOf("sh", "-c", cmd), null, null)
    val output = process.inputStream.bufferedReader().use { it.readText() }
    process.waitFor()
    return output
}